# APEX Running Coach — Deployment Guide

Your app is ready to deploy. Follow these steps exactly. No coding required.

---

## BEFORE YOU START

Make sure you have:
- [ ] A fresh Google Gemini API key from aistudio.google.com
- [ ] A free GitHub account (github.com)
- [ ] A free Vercel account (vercel.com — sign up with your GitHub account)

---

## STEP 1 — Upload your code to GitHub

GitHub is where your code lives. Vercel reads it from there.

1. Go to **github.com** and sign in
2. Click the **"+"** icon in the top-right corner → **"New repository"**
3. Name it: `apex-running-coach`
4. Leave everything else as default → click **"Create repository"**
5. On the next page, click **"uploading an existing file"** (it's a small link)
6. Drag and drop the entire **apex-app folder** contents into the upload area
   - Upload ALL files and folders: `api/`, `src/`, `public/`, `index.html`, `package.json`, `vite.config.js`, `vercel.json`
7. Scroll down → click **"Commit changes"**

Your code is now on GitHub. ✅

---

## STEP 2 — Deploy to Vercel

1. Go to **vercel.com** and sign in with your GitHub account
2. Click **"Add New Project"**
3. You'll see your `apex-running-coach` repository listed — click **"Import"**
4. On the configuration screen:
   - **Framework Preset:** Select **"Vite"** from the dropdown
   - Leave everything else as default
5. Click **"Deploy"**

Vercel will build your app. This takes about 60 seconds. ✅

---

## STEP 3 — Add your Gemini API key (THE IMPORTANT PART)

This is where you safely enter your API key. It never appears in your code.

1. Once deployed, you'll be on your project dashboard
2. Click **"Settings"** in the top navigation
3. Click **"Environment Variables"** in the left sidebar
4. Fill in the form:
   - **Name:** `GEMINI_API_KEY`
   - **Value:** paste your API key here (the one starting with `AIza...`)
   - **Environment:** leave all three checked (Production, Preview, Development)
5. Click **"Save"**

---

## STEP 4 — Redeploy to activate the key

Adding an environment variable requires a fresh deploy to take effect.

1. Click **"Deployments"** in the top navigation
2. Find your most recent deployment → click the **"..."** menu on the right
3. Click **"Redeploy"** → confirm

Wait about 30 seconds. ✅

---

## STEP 5 — Open your live app!

1. Click **"Domains"** in the settings, or just go back to your project overview
2. You'll see a URL like: `apex-running-coach.vercel.app`
3. Click it — your app is live! 🎉

Share this link with anyone. It works on phones, tablets, and computers.

---

## TIPS

**To update your app in the future:**
- Edit files in GitHub directly (click any file → pencil icon to edit)
- Vercel automatically re-deploys within 60 seconds

**Your API key is safe because:**
- It lives only in Vercel's encrypted environment variables
- It never appears in your code or in the browser
- Users of your app cannot see it

**Gemini free tier limits:**
- 1,500 requests per day
- 1 million tokens per minute
- More than enough for personal or small-audience use

---

## NEED HELP?

If something goes wrong, the most common fixes are:
- Make sure ALL files were uploaded to GitHub (especially the `api/` folder)
- Make sure the environment variable name is exactly `GEMINI_API_KEY` (case-sensitive)
- Make sure you redeployed after adding the key
