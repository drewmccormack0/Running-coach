import { useState, useEffect, useRef } from "react";

const RACES = [
  { id: "5k", label: "5K", miles: 3.1, emoji: "🏃", weeks: 8 },
  { id: "10k", label: "10K", miles: 6.2, emoji: "🏃", weeks: 10 },
  { id: "half", label: "Half Marathon", miles: 13.1, emoji: "🌄", weeks: 16 },
  { id: "marathon", label: "Marathon", miles: 26.2, emoji: "⛰️", weeks: 20 },
  { id: "50k", label: "50K Ultra", miles: 31, emoji: "🏔️", weeks: 24 },
  { id: "50m", label: "50 Mile Ultra", miles: 50, emoji: "🌲", weeks: 28 },
  { id: "100k", label: "100K Ultra", miles: 62, emoji: "🦌", weeks: 32 },
  { id: "100m", label: "100 Mile Ultra", miles: 100, emoji: "💀", weeks: 36 },
];
const LEVELS = [
  { id: "beginner", label: "Beginner", desc: "Running less than 6 months" },
  { id: "intermediate", label: "Intermediate", desc: "1–3 years of consistent running" },
  { id: "advanced", label: "Advanced", desc: "3+ years, multiple races completed" },
];
const FOCUSES = [
  { id: "finish", label: "Just Finish", icon: "🏁" },
  { id: "time", label: "Hit a Time Goal", icon: "⏱️" },
  { id: "podium", label: "Podium Contender", icon: "🥇" },
];

async function callCoach({ messages, system }) {
  const res = await fetch("/api/chat", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ messages, system }),
  });
  if (!res.ok) throw new Error("API error");
  const data = await res.json();
  return data.content?.map((b) => b.text || "").join("") || "Keep pushing.";
}

function TypingText({ text, speed = 14 }) {
  const [displayed, setDisplayed] = useState("");
  const [done, setDone] = useState(false);
  useEffect(() => {
    setDisplayed(""); setDone(false);
    let i = 0;
    const iv = setInterval(() => {
      if (i < text.length) { setDisplayed(text.slice(0, i + 1)); i++; }
      else { setDone(true); clearInterval(iv); }
    }, speed);
    return () => clearInterval(iv);
  }, [text]);
  return <span>{displayed}{!done && <span className="cursor">|</span>}</span>;
}

function Terrain() {
  return (
    <svg className="terrain" viewBox="0 0 1440 200" preserveAspectRatio="none">
      <defs>
        <linearGradient id="tg" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#2d5a27" stopOpacity="0.6" />
          <stop offset="100%" stopColor="#1a3518" stopOpacity="0.9" />
        </linearGradient>
      </defs>
      <path d="M0,180 C120,100 240,160 360,120 C480,80 600,150 720,100 C840,50 960,130 1080,90 C1200,50 1320,140 1440,80 L1440,200 L0,200 Z" fill="url(#tg)" />
      <path d="M0,200 C180,130 360,180 540,140 C720,100 900,160 1080,120 C1260,80 1380,160 1440,140 L1440,200 Z" fill="#0f2210" opacity="0.8" />
    </svg>
  );
}

function PulseRing({ active }) {
  if (!active) return null;
  return <div className="pulse-ring"><div className="ring r1"/><div className="ring r2"/><div className="ring r3"/></div>;
}

export default function App() {
  const [screen, setScreen] = useState("home");
  const [race, setRace] = useState(null);
  const [level, setLevel] = useState(null);
  const [focus, setFocus] = useState(null);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [weekPlan, setWeekPlan] = useState(null);
  const [activeTab, setActiveTab] = useState("chat");
  const [step, setStep] = useState(0);
  const chatRef = useRef(null);
  const inputRef = useRef(null);

  useEffect(() => {
    if (chatRef.current) chatRef.current.scrollTop = chatRef.current.scrollHeight;
  }, [messages, loading]);

  const raceInfo = RACES.find((r) => r.id === race);
  const levelInfo = LEVELS.find((l) => l.id === level);
  const focusInfo = FOCUSES.find((f) => f.id === focus);
  const coachSystem = `You are APEX, an elite ultra marathon and running coach. Athlete: ${levelInfo?.label}, training for ${raceInfo?.label} (${raceInfo?.miles} miles), goal: ${focusInfo?.label}. Training window: ${raceInfo?.weeks} weeks. Speak with authority and trail wisdom. Be specific. Use vivid language. Never be generic.`;

  const startCoach = async () => {
    setScreen("coach"); setActiveTab("chat"); setLoading(true);
    try {
      const text = await callCoach({
        system: coachSystem,
        messages: [{ role: "user", content: `Give a powerful personalized welcome to a ${levelInfo?.label} runner training for a ${raceInfo?.label}. Focus: ${focusInfo?.label}. 3-4 paragraphs, no headers.` }],
      });
      setMessages([{ role: "assistant", content: text }]);
    } catch {
      setMessages([{ role: "assistant", content: "Welcome, athlete. I'm APEX. Let's build something extraordinary." }]);
    }
    setLoading(false);
  };

  const sendMessage = async () => {
    if (!input.trim() || loading) return;
    const userMsg = input.trim(); setInput("");
    const newMessages = [...messages, { role: "user", content: userMsg }];
    setMessages(newMessages); setLoading(true);
    try {
      const text = await callCoach({ messages: newMessages, system: coachSystem });
      setMessages([...newMessages, { role: "assistant", content: text }]);
    } catch {
      setMessages([...newMessages, { role: "assistant", content: "Connection lost on the trail. Try again." }]);
    }
    setLoading(false);
  };

  const generatePlan = async () => {
    setActiveTab("plan");
    if (weekPlan) return;
    setLoading(true);
    try {
      const text = await callCoach({
        system: "You are an elite running coach. Return ONLY a valid JSON array, no markdown, no backticks, no explanation. Format: [{week,theme,totalMiles,days:[{day,workout,miles,type}]}]. Types: easy|tempo|long|rest|cross|intervals.",
        messages: [{ role: "user", content: `4-week opening training block for ${levelInfo?.label} targeting ${raceInfo?.label} (${raceInfo?.miles}mi) in ${raceInfo?.weeks} weeks. Goal: ${focusInfo?.label}.` }],
      });
      setWeekPlan(JSON.parse(text.replace(/```json|```/g, "").trim()));
    } catch { setWeekPlan([]); }
    setLoading(false);
  };

  const typeColors = { easy:"#4ade80", tempo:"#facc15", long:"#f97316", rest:"#64748b", cross:"#22d3ee", intervals:"#f472b6" };

  if (screen === "home") return (
    <div className="app home-screen">
      <Terrain />
      <div className="stars">{[...Array(40)].map((_,i)=><div key={i} className="star" style={{left:`${Math.random()*100}%`,top:`${Math.random()*60}%`,animationDelay:`${Math.random()*3}s`,width:`${1+Math.random()*2}px`,height:`${1+Math.random()*2}px`}}/>)}</div>
      <div className="home-content">
        <div className="apex-badge">APEX</div>
        <h1 className="home-title">From First 5K<br/>to 100 Miles</h1>
        <p className="home-sub">AI-powered ultra marathon coaching for every runner</p>
        <div className="race-preview">{RACES.map(r=><div key={r.id} className="race-chip">{r.emoji} {r.label}</div>)}</div>
        <button className="cta-btn" onClick={()=>setScreen("setup")}>Start Your Journey →</button>
        <p className="home-tagline">The trail doesn't care about excuses.</p>
      </div>
      <style>{css}</style>
    </div>
  );

  if (screen === "setup") return (
    <div className="app setup-screen">
      <Terrain />
      <div className="setup-content">
        <div className="setup-header">
          <button className="back-btn" onClick={()=>{setScreen("home");setStep(0);}}>← Back</button>
          <div className="step-indicator">{["Race","Level","Goal"].map((s,i)=>(
            <div key={i} className={`step-dot ${i===step?"active":i<step?"done":""}`}>
              <span>{i<step?"✓":i+1}</span><label>{s}</label>
            </div>
          ))}</div>
        </div>
        {step===0&&<div className="setup-panel">
          <h2>What's your target race?</h2>
          <p className="setup-desc">Choose your destination. We'll build the path.</p>
          <div className="race-grid">{RACES.map(r=>(
            <button key={r.id} className={`race-card ${race===r.id?"selected":""}`} onClick={()=>setRace(r.id)}>
              <span className="race-emoji">{r.emoji}</span>
              <span className="race-name">{r.label}</span>
              <span className="race-miles">{r.miles} mi · {r.weeks} wks</span>
            </button>
          ))}</div>
          <button className="next-btn" disabled={!race} onClick={()=>setStep(1)}>Next →</button>
        </div>}
        {step===1&&<div className="setup-panel">
          <h2>What's your experience level?</h2>
          <p className="setup-desc">Honest assessment = better coaching.</p>
          <div className="level-grid">{LEVELS.map(l=>(
            <button key={l.id} className={`level-card ${level===l.id?"selected":""}`} onClick={()=>setLevel(l.id)}>
              <strong>{l.label}</strong><span>{l.desc}</span>
            </button>
          ))}</div>
          <div className="nav-row">
            <button className="back-step-btn" onClick={()=>setStep(0)}>← Back</button>
            <button className="next-btn" disabled={!level} onClick={()=>setStep(2)}>Next →</button>
          </div>
        </div>}
        {step===2&&<div className="setup-panel">
          <h2>What's your goal?</h2>
          <p className="setup-desc">Your motivation shapes your training.</p>
          <div className="focus-grid">{FOCUSES.map(f=>(
            <button key={f.id} className={`focus-card ${focus===f.id?"selected":""}`} onClick={()=>setFocus(f.id)}>
              <span className="focus-icon">{f.icon}</span><span>{f.label}</span>
            </button>
          ))}</div>
          <div className="nav-row">
            <button className="back-step-btn" onClick={()=>setStep(1)}>← Back</button>
            <button className="next-btn launch" disabled={!focus} onClick={startCoach}>Meet Your Coach →</button>
          </div>
        </div>}
      </div>
      <style>{css}</style>
    </div>
  );

  return (
    <div className="app coach-screen">
      <div className="coach-header">
        <div className="coach-header-left">
          <button className="back-btn" onClick={()=>setScreen("setup")}>←</button>
          <div className="apex-mini">APEX</div>
          <div className="coach-meta">
            <span className="coach-race">{raceInfo?.emoji} {raceInfo?.label}</span>
            <span className="coach-badges">
              <span className="badge">{levelInfo?.label}</span>
              <span className="badge">{focusInfo?.label}</span>
            </span>
          </div>
        </div>
        <PulseRing active={loading}/>
      </div>
      <div className="tab-bar">
        <button className={`tab ${activeTab==="chat"?"active":""}`} onClick={()=>setActiveTab("chat")}>💬 Coach Chat</button>
        <button className={`tab ${activeTab==="plan"?"active":""}`} onClick={generatePlan}>📋 Training Plan</button>
      </div>
      {activeTab==="chat"&&<>
        <div className="chat-window" ref={chatRef}>
          {messages.map((m,i)=>(
            <div key={i} className={`message ${m.role}`}>
              {m.role==="assistant"&&<div className="coach-avatar">A</div>}
              <div className="bubble">
                {m.role==="assistant"&&i===messages.length-1&&!loading
                  ?<TypingText text={m.content}/>
                  :m.content.split("\n").map((l,j)=><p key={j}>{l}</p>)}
              </div>
            </div>
          ))}
          {loading&&<div className="message assistant">
            <div className="coach-avatar">A</div>
            <div className="bubble loading-bubble"><span/><span/><span/></div>
          </div>}
        </div>
        <div className="chat-input-bar">
          <div className="suggested-questions">
            {["Weekly schedule?","Nutrition tips?","Injury prevention?","Pace strategy?"].map(q=>(
              <button key={q} className="suggestion" onClick={()=>{setInput(q);inputRef.current?.focus();}}>{q}</button>
            ))}
          </div>
          <div className="input-row">
            <input ref={inputRef} className="chat-input" value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>e.key==="Enter"&&sendMessage()} placeholder="Ask your coach anything..."/>
            <button className="send-btn" onClick={sendMessage} disabled={loading||!input.trim()}>↑</button>
          </div>
        </div>
      </>}
      {activeTab==="plan"&&<div className="plan-panel">
        {loading&&!weekPlan&&<div className="plan-loading"><div className="spinner"/><p>Building your training blocks...</p></div>}
        {weekPlan&&weekPlan.length===0&&<p style={{color:"#aaa",textAlign:"center",marginTop:40}}>Could not load plan. Try again.</p>}
        {weekPlan&&weekPlan.map((week,wi)=>(
          <div key={wi} className="week-block">
            <div className="week-header">
              <span className="week-num">Week {week.week}</span>
              <span className="week-theme">{week.theme}</span>
              <span className="week-miles">{week.totalMiles} mi</span>
            </div>
            <div className="day-list">{week.days?.map((day,di)=>(
              <div key={di} className="day-row" style={{borderLeft:`3px solid ${typeColors[day.type]||"#555"}`}}>
                <span className="day-name">{day.day}</span>
                <span className="day-workout">{day.workout}</span>
                <span className="day-miles" style={{color:typeColors[day.type]||"#aaa"}}>{day.miles>0?`${day.miles}mi`:"—"}</span>
              </div>
            ))}</div>
          </div>
        ))}
      </div>}
      <style>{css}</style>
    </div>
  );
}

const css = `
  @import url('https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:wght@300;400;500&family=Space+Mono:wght@400;700&display=swap');
  *,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
  .app{min-height:100vh;background:#0a1a0b;color:#e8f5e3;font-family:'DM Sans',sans-serif;overflow-x:hidden;}
  .home-screen{position:relative;display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:100vh;}
  .terrain{position:absolute;bottom:0;left:0;width:100%;height:200px;z-index:0;}
  .stars{position:absolute;top:0;left:0;width:100%;height:70%;pointer-events:none;}
  .star{position:absolute;background:#c8e6c0;border-radius:50%;animation:twinkle 3s infinite alternate;}
  @keyframes twinkle{from{opacity:0.2;}to{opacity:1;}}
  .home-content{position:relative;z-index:1;text-align:center;padding:40px 20px;max-width:700px;}
  .apex-badge{font-family:'Bebas Neue',sans-serif;font-size:13px;letter-spacing:6px;color:#4ade80;border:1px solid #2d6a30;padding:5px 14px;display:inline-block;margin-bottom:28px;}
  .home-title{font-family:'Bebas Neue',sans-serif;font-size:clamp(56px,12vw,96px);line-height:0.95;color:#e8f5e3;margin-bottom:20px;}
  .home-sub{font-size:18px;color:#86b88a;font-weight:300;margin-bottom:36px;}
  .race-preview{display:flex;flex-wrap:wrap;gap:8px;justify-content:center;margin-bottom:40px;}
  .race-chip{background:rgba(74,222,128,0.08);border:1px solid rgba(74,222,128,0.2);border-radius:20px;padding:6px 14px;font-size:13px;color:#86b88a;font-family:'Space Mono',monospace;}
  .cta-btn{background:#4ade80;color:#0a1a0b;border:none;font-family:'Bebas Neue',sans-serif;font-size:22px;letter-spacing:3px;padding:18px 48px;border-radius:3px;cursor:pointer;transition:all 0.2s;margin-bottom:20px;}
  .cta-btn:hover{background:#86efac;transform:translateY(-2px);box-shadow:0 8px 30px rgba(74,222,128,0.3);}
  .home-tagline{font-size:13px;color:#3d6b42;font-style:italic;}
  .setup-screen{min-height:100vh;position:relative;}
  .setup-content{position:relative;z-index:1;max-width:680px;margin:0 auto;padding:24px 20px 40px;}
  .setup-header{display:flex;align-items:center;gap:20px;margin-bottom:40px;}
  .back-btn{background:none;border:1px solid #2d6a30;color:#86b88a;font-family:'Space Mono',monospace;font-size:13px;padding:8px 14px;border-radius:3px;cursor:pointer;}
  .back-btn:hover{background:rgba(74,222,128,0.08);}
  .step-indicator{display:flex;gap:20px;flex:1;justify-content:center;}
  .step-dot{display:flex;flex-direction:column;align-items:center;gap:4px;}
  .step-dot span{width:32px;height:32px;border-radius:50%;border:2px solid #2d6a30;display:flex;align-items:center;justify-content:center;font-family:'Space Mono',monospace;font-size:13px;color:#3d6b42;transition:all 0.3s;}
  .step-dot.active span{border-color:#4ade80;color:#4ade80;box-shadow:0 0 12px rgba(74,222,128,0.4);}
  .step-dot.done span{background:#4ade80;border-color:#4ade80;color:#0a1a0b;}
  .step-dot label{font-size:11px;color:#3d6b42;letter-spacing:1px;}
  .setup-panel h2{font-family:'Bebas Neue',sans-serif;font-size:40px;color:#e8f5e3;margin-bottom:8px;}
  .setup-desc{color:#86b88a;font-size:15px;margin-bottom:28px;}
  .race-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:10px;margin-bottom:28px;}
  .race-card{background:rgba(255,255,255,0.03);border:1px solid #1e3d20;border-radius:6px;padding:16px 12px;cursor:pointer;display:flex;flex-direction:column;align-items:center;gap:6px;transition:all 0.2s;}
  .race-card:hover{border-color:#2d6a30;background:rgba(74,222,128,0.05);}
  .race-card.selected{border-color:#4ade80;background:rgba(74,222,128,0.1);box-shadow:0 0 16px rgba(74,222,128,0.15);}
  .race-emoji{font-size:24px;}.race-name{font-weight:500;font-size:14px;color:#e8f5e3;}.race-miles{font-size:11px;color:#86b88a;font-family:'Space Mono',monospace;}
  .level-grid{display:flex;flex-direction:column;gap:10px;margin-bottom:28px;}
  .level-card{background:rgba(255,255,255,0.03);border:1px solid #1e3d20;border-radius:6px;padding:18px 20px;cursor:pointer;text-align:left;transition:all 0.2s;display:flex;flex-direction:column;gap:4px;}
  .level-card strong{color:#e8f5e3;font-size:17px;}.level-card span{color:#86b88a;font-size:13px;}
  .level-card:hover{border-color:#2d6a30;}.level-card.selected{border-color:#4ade80;background:rgba(74,222,128,0.1);}
  .focus-grid{display:flex;gap:12px;margin-bottom:28px;flex-wrap:wrap;}
  .focus-card{flex:1;min-width:140px;background:rgba(255,255,255,0.03);border:1px solid #1e3d20;border-radius:6px;padding:24px 16px;cursor:pointer;display:flex;flex-direction:column;align-items:center;gap:10px;transition:all 0.2s;font-size:15px;color:#e8f5e3;}
  .focus-icon{font-size:32px;}.focus-card:hover{border-color:#2d6a30;}.focus-card.selected{border-color:#4ade80;background:rgba(74,222,128,0.1);}
  .nav-row{display:flex;gap:12px;}
  .back-step-btn{background:none;border:1px solid #2d6a30;color:#86b88a;font-size:15px;padding:14px 24px;border-radius:3px;cursor:pointer;}
  .next-btn{flex:1;background:#4ade80;color:#0a1a0b;border:none;font-family:'Bebas Neue',sans-serif;font-size:20px;letter-spacing:2px;padding:14px 32px;border-radius:3px;cursor:pointer;transition:all 0.2s;}
  .next-btn:disabled{background:#1e3d20;color:#3d6b42;cursor:not-allowed;}
  .next-btn:not(:disabled):hover{background:#86efac;}
  .next-btn.launch{background:linear-gradient(135deg,#4ade80,#22d3ee);}
  .coach-screen{display:flex;flex-direction:column;height:100vh;}
  .coach-header{display:flex;align-items:center;justify-content:space-between;padding:14px 18px;border-bottom:1px solid #1e3d20;background:rgba(10,26,11,0.95);backdrop-filter:blur(10px);position:sticky;top:0;z-index:10;}
  .coach-header-left{display:flex;align-items:center;gap:14px;}
  .apex-mini{font-family:'Bebas Neue',sans-serif;font-size:20px;letter-spacing:3px;color:#4ade80;}
  .coach-meta{display:flex;flex-direction:column;gap:3px;}
  .coach-race{font-size:15px;font-weight:500;color:#e8f5e3;}
  .coach-badges{display:flex;gap:6px;}
  .badge{font-size:11px;font-family:'Space Mono',monospace;background:rgba(74,222,128,0.1);border:1px solid rgba(74,222,128,0.25);color:#4ade80;padding:2px 8px;border-radius:10px;}
  .pulse-ring{position:relative;width:36px;height:36px;display:flex;align-items:center;justify-content:center;}
  .ring{position:absolute;border-radius:50%;border:2px solid #4ade80;animation:pulse-out 1.5s infinite;}
  .r1{width:12px;height:12px;}.r2{width:22px;height:22px;animation-delay:0.3s;opacity:0.7;}.r3{width:34px;height:34px;animation-delay:0.6s;opacity:0.4;}
  @keyframes pulse-out{0%{transform:scale(0.8);opacity:1;}100%{transform:scale(1.4);opacity:0;}}
  .tab-bar{display:flex;border-bottom:1px solid #1e3d20;}
  .tab{flex:1;background:none;border:none;color:#3d6b42;font-family:'DM Sans',sans-serif;font-size:14px;padding:12px;cursor:pointer;transition:all 0.2s;border-bottom:2px solid transparent;}
  .tab.active{color:#4ade80;border-bottom-color:#4ade80;background:rgba(74,222,128,0.05);}
  .chat-window{flex:1;overflow-y:auto;padding:20px 16px;display:flex;flex-direction:column;gap:18px;}
  .chat-window::-webkit-scrollbar{width:4px;}.chat-window::-webkit-scrollbar-track{background:#0a1a0b;}.chat-window::-webkit-scrollbar-thumb{background:#2d6a30;border-radius:2px;}
  .message{display:flex;gap:12px;max-width:720px;width:100%;}
  .message.user{flex-direction:row-reverse;margin-left:auto;}
  .coach-avatar{width:36px;height:36px;min-width:36px;border-radius:50%;background:linear-gradient(135deg,#4ade80,#22d3ee);display:flex;align-items:center;justify-content:center;font-family:'Bebas Neue',sans-serif;font-size:18px;color:#0a1a0b;}
  .bubble{background:rgba(255,255,255,0.04);border:1px solid #1e3d20;border-radius:12px;padding:14px 16px;font-size:14.5px;line-height:1.7;color:#c8e6c0;max-width:580px;}
  .bubble p:not(:last-child){margin-bottom:10px;}
  .message.user .bubble{background:rgba(74,222,128,0.1);border-color:rgba(74,222,128,0.3);color:#e8f5e3;border-radius:12px 12px 3px 12px;}
  .message.assistant .bubble{border-radius:3px 12px 12px 12px;}
  .loading-bubble{display:flex;gap:6px;align-items:center;padding:16px;}
  .loading-bubble span{width:8px;height:8px;border-radius:50%;background:#4ade80;animation:bounce 1.2s infinite;}
  .loading-bubble span:nth-child(2){animation-delay:0.2s;}.loading-bubble span:nth-child(3){animation-delay:0.4s;}
  @keyframes bounce{0%,80%,100%{transform:scale(0.6);opacity:0.4;}40%{transform:scale(1);opacity:1;}}
  .cursor{animation:blink 0.7s infinite;color:#4ade80;}
  @keyframes blink{0%,100%{opacity:1;}50%{opacity:0;}}
  .chat-input-bar{padding:12px 16px 16px;border-top:1px solid #1e3d20;background:rgba(10,26,11,0.95);}
  .suggested-questions{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:10px;}
  .suggestion{background:none;border:1px solid #1e3d20;color:#86b88a;font-size:12px;padding:5px 12px;border-radius:14px;cursor:pointer;transition:all 0.15s;font-family:'DM Sans',sans-serif;}
  .suggestion:hover{border-color:#4ade80;color:#4ade80;background:rgba(74,222,128,0.07);}
  .input-row{display:flex;gap:10px;}
  .chat-input{flex:1;background:rgba(255,255,255,0.04);border:1px solid #2d6a30;border-radius:6px;color:#e8f5e3;font-family:'DM Sans',sans-serif;font-size:15px;padding:12px 16px;outline:none;transition:border-color 0.2s;}
  .chat-input:focus{border-color:#4ade80;}.chat-input::placeholder{color:#3d6b42;}
  .send-btn{background:#4ade80;color:#0a1a0b;border:none;width:44px;height:44px;border-radius:6px;font-size:20px;cursor:pointer;transition:all 0.2s;display:flex;align-items:center;justify-content:center;}
  .send-btn:disabled{background:#1e3d20;color:#3d6b42;cursor:not-allowed;}
  .send-btn:not(:disabled):hover{background:#86efac;transform:scale(1.05);}
  .plan-panel{flex:1;overflow-y:auto;padding:20px 16px;}
  .plan-loading{display:flex;flex-direction:column;align-items:center;gap:16px;padding:60px 20px;color:#86b88a;}
  .spinner{width:36px;height:36px;border:3px solid #1e3d20;border-top-color:#4ade80;border-radius:50%;animation:spin 0.8s linear infinite;}
  @keyframes spin{to{transform:rotate(360deg);}}
  .week-block{background:rgba(255,255,255,0.03);border:1px solid #1e3d20;border-radius:8px;margin-bottom:16px;overflow:hidden;}
  .week-header{display:flex;align-items:center;gap:12px;padding:14px 16px;background:rgba(74,222,128,0.05);border-bottom:1px solid #1e3d20;}
  .week-num{font-family:'Bebas Neue',sans-serif;font-size:18px;letter-spacing:1px;color:#4ade80;min-width:60px;}
  .week-theme{flex:1;font-size:14px;color:#c8e6c0;font-style:italic;}
  .week-miles{font-family:'Space Mono',monospace;font-size:13px;color:#86b88a;}
  .day-list{padding:8px 0;}
  .day-row{display:flex;align-items:center;gap:12px;padding:9px 16px;margin:4px 12px;border-radius:4px;background:rgba(255,255,255,0.02);}
  .day-name{font-family:'Space Mono',monospace;font-size:11px;color:#86b88a;min-width:36px;text-transform:uppercase;}
  .day-workout{flex:1;font-size:13px;color:#c8e6c0;}
  .day-miles{font-family:'Space Mono',monospace;font-size:13px;font-weight:700;min-width:36px;text-align:right;}
`;
